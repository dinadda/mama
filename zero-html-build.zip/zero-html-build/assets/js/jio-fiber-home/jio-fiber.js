$(document).ready(function(){

// $("html").niceScroll({
//     scrollspeed:"170",
//     //autohidemode:false,
//     zindex:"10000",
//     horizrailenabled:false
// });

$('[data-toggle="tooltip"]').tooltip();

var owl = $(".owl-carousel");
if( owl.length ){
  owl.owlCarousel({
  navigation : true,
  rewindNav : false, 
  items : 1, //10 items above 1000px browser width
  itemsDesktop : [1024,1], //5 items between 1000px and 901px
  itemsDesktopSmall : [900,1], // betweem 900px and 601px
  itemsTablet: [600,1], //2 items between 600 and 0
  itemsMobile : false, // itemsMobile disabled - inherit from itemsTablet option
  slideSpeed :2000,
  afterAction: function(){  
      if ( this.itemsAmount > this.visibleItems.length ) {
        $('.next').show();
        $('.prev').show();

        $('.next').removeClass('disabled');
        $('.prev').removeClass('disabled');
        if ( this.currentItem == 0 ) {
          $('.prev').addClass('disabled');
        }
        if ( this.currentItem == this.maximumItem ) {
          $('.next').addClass('disabled');
        }

      } else {
        $('.next').hide();
        $('.prev').hide();
      }
    }
  });

}



$('.links .addpro').on( "click", function(e) {
    $(".pro-cal-dropbox").css("bottom","calc(146px - 100vh)");   
    $(".explor-btn a.exp-btn").css('display','block');

});


$(".interested-svg-wrap").animate({opacity:0});

// Explor btn  //////////////   
$(".explor-btn a.exp-btn").click(function () {

    $(".interested-svg-wrap").delay( 3500 ).animate({opacity:1});

    $(".slider-text").css('bottom','-100px');
    $(".pro-cal-dropbox").css({"bottom":"0px"});
    $(".explor-btn a.exp-btn").css('display','none');
    $(".explor-btn a.close-btn").css('display','block');
    $(".disabled-slider").css({ "opacity": "1", "z-index": "98"});
    $(".links .item .addpro, .owl-drag").css('pointer-events','none');
    
}); 

 
// Close reset value  //////////////    
$(".explor-btn a.close-btn").click(function () {
    $(".slider-text").css('bottom','77%');
    $(".pro-cal-dropbox").css('bottom','-662px');
    $(".links .item .addpro, .owl-drag").css('pointer-events','auto');
    $(".disabled-slider").css({ "opacity": "0", "z-index": "1", "pointer-events": "none"});
    $(".explor-btn a.close-btn").css('display','none');
    $(".links .addpro").removeClass('pro-disable');
    $("ul.pro-cls li.quantity").css('display','none');
    $("ul#list .fiber-progess-bar li").remove();
    $("input.dec").prop('disabled', true);
    a = 0; 
    b = 0;
    c = 0;
    d = 0;
    e = 0;
    f = 0;
    g = 0;
    
});  



//progress bar

$(".explor-btn").on('click', function () {

    //for jio fiber progress bar

    var barlistwidth= $(".fiber-bar .fiber-progess-bar li").width();
    var listnumber = $( ".fiber-bar .fiber-progess-bar li" ).length;2
    var progressbarwidth = barlistwidth*listnumber;
    $(".fiber-bar .fiber-progess-bar").animate({'width': progressbarwidth});


    //for broadband progress bar

    var broadbandbarlistwidth= $(".broadband .fiber-progess-bar li").width();
    var broadbandlistnumber = $( ".broadband .fiber-progess-bar li" ).length;
    var broadbandprogressbarwidth = broadbandbarlistwidth*broadbandlistnumber;
    $(".broadband .fiber-progess-bar").animate({'width': broadbandprogressbarwidth});

 
   
});







// Wall Lamp  //////////////   

$(".wall-lamp .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="wall-lamp-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="wall-lamp-pro-load"></li>');
}); //this is for first progress bar


$(".wall-lamp .dec").click(function () {
    $("ul#list .fiber-progess-bar li.wall-lamp-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.wall-lamp-pro-load:last-child").remove();
}); //this is for second progress bar

$('li.wall-lamp-qty').hide();//this is for selected device hide item

$(".wall-lamp .inc").one("click",function(){
    $('.pro-cls').show('li.wall-lamp-qty'); //this is for selected device hide item
});

                                


$(".wall-lamp input.dec").prop('disabled', true); //this is for decrement disabled
    var d = 0;

$(".wall-lamp .inc").click(function () {
        $(".wall-lamp input.dec").prop('disabled', false);
        if (d < 5) {
            d++;
             $(".wall-lamp-qty.quantity").show();
        } else if (d = 6) {
            d = 6;
            $(".wall-lamp input.inc").prop('disabled', true);
            $(".wall-lamp .dec").show();
            $(".wall-lamp .addpro").toggleClass('pro-disable');            
        }       
        document.getElementById("wall-lamp-count").innerHTML = d;
}); //this is for increment functionality



$(".wall-lamp .dec").click(function () {
    $(".wall-lamp input.inc").prop('disabled', false);
        if (d > 1) {
            --d;            
        } else if (d = 1) {
            d = 0; 
            $(".wall-lamp input.dec").prop('disabled', true);
            $(".wall-lamp input.inc").prop('disabled', false);
            $(".wall-lamp-qty.quantity").hide();
            $(".wall-lamp .inc").show();
            // $(".wall-lamp .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("wall-lamp-count").innerHTML = d;
}); //this is for increment functionality





//tv ////////////// 
$(".tv .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="tv-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="tv-pro-load"></li>');
});

$(".tv .dec").click(function () {
    $("ul#list .fiber-progess-bar li.tv-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.tv-pro-load:last-child").remove();
});


$('li.tv-qty').hide();
$(".tv .inc").one("click",function(){
    $('.pro-cls').show('li.tv-qty');
});

$(".tv input.dec").prop('disabled', true);
    var c = 0;

$(".tv .inc").click(function () {
    $(".tv input.dec").prop('disabled', false);
        if (c < 4) {
            c++;
             $(".tv-qty.quantity").show();
        } else if (c = 5) {
            c = 5;
             $(".tv input.inc").prop('disabled', true);
            $(".tv .dec").show();
            $(".tv .addpro").toggleClass('pro-disable');
        }
        document.getElementById("tv-count").innerHTML = c;
});


$(".tv .dec").click(function () {
     $(".tv input.inc").prop('disabled', false);
        if (c > 1) {
            --c;            
        } else if (c = 1) {
            c = 0;
            $(".tv input.dec").prop('disabled', true);
            $(".tv input.inc").prop('disabled', false); 
            $(".tv-qty.quantity").hide();
            $(".tv .inc").show();
            $(".tv .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("tv-count").innerHTML = c;
});




// table ////////////// 
$(".table .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="table-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="table-pro-load"></li>');
});

$(".table .dec").click(function () {
    $("ul#list .fiber-progess-bar li.table-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.table-pro-load:last-child").remove();
});

$('li.table-qty').hide();
$(".table .inc").one("click",function(){
    $('.pro-cls').show('li.table-qty');
});

    


$(".table input.dec").prop('disabled', true);
    var a = 0;

$(".table .inc").click(function () {
    $(".table input.dec").prop('disabled', false);
        if (a < 4) {
            a++;
             $(".table-qty.quantity").show();
        } else if (a = 5) {
            a = 5;
            $(".table input.inc").prop('disabled', true);
            $(".table .dec").show();
            $(".table .addpro").toggleClass('pro-disable');
        }
        document.getElementById("table-count").innerHTML = a;
});


$(".table .dec").click(function () {
     $(".table input.inc").prop('disabled', false);
        if (a > 1) {
            --a;            
        } else if (a = 1) {
            a = 0;
            $(".table input.dec").prop('disabled', true);
            $(".table input.inc").prop('disabled', false); 
            $(".table-qty.quantity").hide();
            $(".table .inc").show();
            $(".table .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("table-count").innerHTML = a;
});




//sofa ////////////// 
$(".sofa .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="sofa-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="sofa-pro-load"></li>');
});

$(".sofa .dec").click(function () {
    $("ul#list .fiber-progess-bar li.sofa-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.sofa-pro-load:last-child").remove();
});

$('li.sofa-qty').hide();
$(".sofa .inc").one("click",function(){

    $('.pro-cls').show('li.sofa-qty');
   
});

$(".sofa input.dec").prop('disabled', true);
    var e = 0;

$(".sofa .inc").click(function () {
    $(".sofa input.dec").prop('disabled', false);
        if (e < 4) {
            e++;
             $(".sofa-qty.quantity").show();
        } else if (e = 5) {
            e = 5;
            $(".sofa input.inc").prop('disabled', true);
            $(".sofa .dec").show();
            $(".sofa .addpro").toggleClass('pro-disable');
        }
        document.getElementById("sofa-count").innerHTML = e;
});


$(".sofa .dec").click(function () {
     $(".sofa input.inc").prop('disabled', false);

        if (e > 1) {
            --e;            
        } else if (e = 1) {
            e = 0; 
            $(".sofa input.dec").prop('disabled', true);
            $(".sofa input.inc").prop('disabled', false);
            $(".sofa-qty.quantity").hide();
            $(".sofa .inc").show();
            $(".sofa .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("sofa-count").innerHTML = e;
});


//ac ////////////// 
$(".ac .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="ac-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="ac-pro-load"></li>');
});

$(".ac .dec").click(function () {
    $("ul#list .fiber-progess-bar li.ac-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.ac-pro-load:last-child").remove();
});

$('.ac-qty').hide();
$(".ac .inc").one("click",function(){
    $('.pro-cls').show('li.ac-qty');
});

$(".ac input.dec").prop('disabled', true);
    var b = 0;

$(".ac .inc").click(function () {
    $(".ac input.dec").prop('disabled', false);
        if (b < 4) {
            b++;
             $(".ac-qty.quantity").show();
        } else if (b = 5) {
            b = 5;
            $(".ac input.inc").prop('disabled', true);
            $(".ac .dec").show();
            $(".ac .addpro").toggleClass('pro-disable');
        }
        document.getElementById("ac-count").innerHTML = b;
});


$(".ac .dec").click(function () {
     $(".ac input.inc").prop('disabled', false);
        if (b > 1) {
            --b;            
        } else if (b = 1) {
            b = 0;
            $(".ac input.dec").prop('disabled', true);
            $(".ac input.inc").prop('disabled', false); 
            $(".ac-qty.quantity").hide();
            $(".ac .inc").show();
            $(".ac .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("ac-count").innerHTML = b;
});





//tablet ////////////// 
$(".tablet .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="tablet-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="tablet-pro-load"></li>');
});

$(".tablet .dec").click(function () {
    $("ul#list .fiber-progess-bar li.tablet-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.tablet-pro-load:last-child").remove();
});

$('li.tablet-qty').hide();
$(".tablet .inc").one("click",function(){

    $('.pro-cls').show('li.tablet-qty');
   
});

$(".tablet input.dec").prop('disabled', true);
    var e = 0;

$(".tablet .inc").click(function () {
    $(".tablet input.dec").prop('disabled', false);
        if (e < 4) {
            e++;
             $(".tablet-qty.quantity").show();
        } else if (e = 5) {
            e = 5;
            $(".tablet input.inc").prop('disabled', true);
            $(".tablet .dec").show();
            $(".tablet .addpro").toggleClass('pro-disable');
        }
        document.getElementById("tablet-count").innerHTML = e;
});


$(".tablet .dec").click(function () {
     $(".tablet input.inc").prop('disabled', false);

        if (e > 1) {
            --e;            
        } else if (e = 1) {
            e = 0; 
            $(".tablet input.dec").prop('disabled', true);
            $(".tablet input.inc").prop('disabled', false);
            $(".tablet-qty.quantity").hide();
            $(".tablet .inc").show();
            $(".tablet .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("tablet-count").innerHTML = e;
});



//phone ////////////// 
$(".phone .inc").click(function () {
    $('ul#list .fiber-progess-bar').append('<li class="phone-pro-load"></li>');
    $('.broadband ul#list .fiber-progess-bar').append('<li class="phone-pro-load"></li>');
});

$(".phone .dec").click(function () {
    $("ul#list .fiber-progess-bar li.phone-pro-load:last-child").remove();
    $(".broadband ul#list .fiber-progess-bar li.phone-pro-load:last-child").remove();
});


$('.phone-qty').hide();
$(".phone .inc").one("click",function(){
    $('.pro-cls').show('li.phone-qty');
});

$(".phone input.dec").prop('disabled', true);
    var g = 0;

$(".phone .inc").click(function () {
    $(".phone input.dec").prop('disabled', false);
        if (g < 4) {
            g++;
             $(".phone-qty.quantity").show();
        } else if (g = 5) {
            g = 5;
             $(".phone input.inc").prop('disabled', true);
            $(".phone .dec").show();
            $(".phone .addpro").toggleClass('pro-disable');
        }
        document.getElementById("phone-count").innerHTML = g;
});


$(".phone .dec").click(function () {
    $(".phone input.inc").prop('disabled', false);
        if (g > 1) {
            --g;            
        } else if (g = 1) {
            g = 0;
            $(".phone input.dec").prop('disabled', true);
            $(".phone input.inc").prop('disabled', false); 
            $(".phone-qty.quantity").hide();
            $(".phone .inc").show();
            $(".phone .addpro").toggleClass('pro-disable'); 
        }
        document.getElementById("phone-count").innerHTML = g;
});

// scrollmagic js start

// init controller
var controller = new ScrollMagic.Controller({});

//nav controller
// $('.scroll-cont a').on('click',function() {
//     var targetSection = $(this).attr('href').substring(1);
//     var targetPerc = (targetSection-1) / ($('.scroll-cont a').length-1);
//     var targetPos = scene.scrollOffset() + (scene.duration()*targetPerc);
//     controller.scrollTo(targetPos);
// });

  
    // build scene
    var wallscene = new ScrollMagic.Scene({
        triggerElement: "#inner-fiber-section", 
        duration: 1000,
        tweenChanges: true,
        triggerHook: 0.3
    })
    .setClassToggle("#inner-fiber-section" ,"active")
    // .addIndicators() // add indicators (requires plugin)
    .addTo(controller);

	
	
	//ipad features scene
 //     if($(window).width() <= 768) {
	
	//  var wallscene = new ScrollMagic.Scene({
 //       triggerElement: "#inner-fiber-section", 
 //        duration: 500
 //        tweenChanges: true,
 //        triggerHook: 0.3

 //   })
 // .setClassToggle("#inner-fiber-section" ,"active")
   
 //    .addTo(controller);

	// }
	
	

     // build scene
    var wallsetpin = new ScrollMagic.Scene({
        triggerElement:"#masthead-fiber-section2", 
        duration: 200,
        triggerHook: 0
    })
    .setPin("#masthead-fiber-section2")
    //.addIndicators() // add indicators (requires plugin)
    .addTo(controller);



// start js for path for filling section2
// function pathPrepare ($el) {
//     var lineLength = $el[0].getTotalLength();
//     $el.css("stroke-dasharray", lineLength);
//     $el.css("stroke-dashoffset", lineLength);
// }

// var $path01 = $("path#path01");
// var $path02 = $("path#path02");

// var $path1 = $("path#path1");
// var $path2 = $("path#path2");
// var $path3 = $("path#path3");
// var $path4 = $("path#path4");
// var $path5 = $("path#path5");

// var $path6 = $("path#path6");
// var $path7 = $("path#path7");
// var $path8 = $("path#path8");
// var $path9 = $("path#path9");
// var $path10 = $("path#path10");
// var $path11= $("path#path11");

// var $path12 = $("path#path12");
// var $path13 = $("path#path13");
// var $path14 = $("path#path14");
// var $path15 = $("path#path15");
// var $path16 = $("path#path16");

// var $path17 = $("path#path17");
// var $path17a = $("path#path17a");
// var $path18 = $("path#path18");
// var $path19 = $("path#path19");
// var $path20 = $("path#path20");
// var $path21 = $("path#path21");
// var $path22 = $("path#path22");
// var $path23 = $("path#path23");
// var $path24 = $("path#path24");
// var $path25 = $("path#path25");
// var $path26 = $("path#path26");
// var $path27 = $("path#path27");
// var $path28 = $("path#path28");
// var $path29 = $("path#path29");

// var $path30 = $("path#path30");
// var $path31 = $("path#path31");
// var $path32 = $("path#path32");
// var $path33 = $("path#path33");

// var $path34 = $("path#path34");
// var $path35 = $("path#path35");


// pathPrepare($path01);
// pathPrepare($path02);

// pathPrepare($path1);
// pathPrepare($path2);
// pathPrepare($path3);
// pathPrepare($path4);
// pathPrepare($path5);

// pathPrepare($path6);
// pathPrepare($path7);
// pathPrepare($path8);
// pathPrepare($path9);
// pathPrepare($path10);
// pathPrepare($path11);

// pathPrepare($path12);
// pathPrepare($path13);
// pathPrepare($path14);
// pathPrepare($path15);
// pathPrepare($path16);
// pathPrepare($path17);
// pathPrepare($path17a);
// pathPrepare($path18);
// pathPrepare($path19);
// pathPrepare($path20);

// pathPrepare($path21);
// pathPrepare($path22);
// pathPrepare($path23);
// pathPrepare($path24);
// pathPrepare($path25);
// pathPrepare($path26);
// pathPrepare($path27);
// pathPrepare($path28);
// pathPrepare($path29);

// pathPrepare($path30);
// pathPrepare($path31);
// pathPrepare($path32);
// pathPrepare($path33);
  
// pathPrepare($path34);
// pathPrepare($path35);
// end js for path for filling

    // var interestedSectionPath = new TimelineMax() 
    //     .add(TweenMax.to($path01, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),0) 
    //     .add(TweenMax.to($path02, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),1) 
    //     .add(TweenMax.to($path1, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),2)
    //     .add(TweenMax.to('.fiber-step1 .fill-head-text', 1, { opacity: 1}),3)
    //     .add(TweenMax.to('.fiber-step1 .icon-content-wrap', 1, { opacity: 1}),4)
        
    //     .add(TweenMax.to($path2, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),5)
    //     .add(TweenMax.to($path3, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),6)
        
        
    //     .add(TweenMax.to($path4, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),7)
    //     .add(TweenMax.to($path5, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),8)

    //     .add(TweenMax.to('.fiber-step2 .fill-head-text', 1, { opacity: 1}),9)
    //     .add(TweenMax.to($path6, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),10)
    //     .add(TweenMax.to('.fiber-step2 .icon-content-wrap', 1, { opacity: 1}),11)
       

    //     .add(TweenMax.to($path6, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),12)
    //     .add(TweenMax.to($path7, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),13)
    //     .add(TweenMax.to($path8, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),14)
    //     .add(TweenMax.to($path9, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),15)

    //     .add(TweenMax.to('.fiber-step3 .fill-head-text', 0.5, { opacity: 1}),16)
    //     .add(TweenMax.to($path10, 0.5, {strokeDashoffset: 0, ease:Linear.easeNone}),17)
    //     .add(TweenMax.to('.fiber-step3 .icon-content-wrap', 0.5, { opacity: 1}),18)

        
    //     .add(TweenMax.to($path11, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),19)
    //     .add(TweenMax.to($path12, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),20)
    //     .add(TweenMax.to($path13, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),21)
    //     .add(TweenMax.to($path14, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),22)
    //     .add(TweenMax.to($path15, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),23)
    //     .add(TweenMax.to($path16, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),24)


    //     .add(TweenMax.to('.fiber-step4 .fill-head-text', 0.5, { opacity: 1}),25)
    //     .add(TweenMax.to($path10, 0.5, {strokeDashoffset: 0, ease:Linear.easeNone}),26)
    //     .add(TweenMax.to('.fiber-step4 .icon-content-wrap', 0.5, { opacity: 1}),27)

    //     .add(TweenMax.to($path17, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),28)

    //     .add(TweenMax.to($path17a, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),29)

    //     .add(TweenMax.to($path18, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),30)

    //     .add(TweenMax.to($path19, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),31)

    //     .add(TweenMax.to('.feature-slider-wrapper .fill-head-text', 1, { opacity: 1}),32)

    //     .add(TweenMax.to($path29, 3, {strokeDashoffset: 0, ease:Linear.easeNone}),33)
    //     .add(TweenMax.to($path20, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),34)
    //     .add(TweenMax.to('.feaure-image-slider .img-wrap ul', 1, {y: 0}),34)
    //     .add(TweenMax.to('.feaure-image-slider .slider-list-1', 2, {opacity:1}),34)
       

    // if ( screen.width >= 768 && screen.width <= 1024 ){
    //     // alert("tablet");

       
    //     var sectionpath = new ScrollMagic.Scene({
    //         triggerElement: "#interested-section-path", 
    //         // duration: 3250,
    //         duration: 2200,
    //         triggerHook: 0.3
    //     })

    //      .setTween(interestedSectionPath)
    //     // .addIndicators() // add indicators (requires plugin)
    //     .addTo(controller);

    // }else if ( screen.width < 740 ){
    //     // alert("mobile");


    //     var sectionpath = new ScrollMagic.Scene({
    //         triggerElement: "#interested-section-path", 
    //         // duration: 3250,
    //         duration:800,
    //         triggerHook: 0.7
    //     })

    //      .setTween(interestedSectionPath)
    //     // .addIndicators() // add indicators (requires plugin)
    //     .addTo(controller);

    // }else{
    //     // alert("desktop");
        
    //     var sectionpath = new ScrollMagic.Scene({
    //         triggerElement: "#interested-section-path", 
    //         duration: 2800,      
    //         triggerHook: 0.7
    //     })

    //     .setTween(interestedSectionPath)
    //     // .addIndicators() // add indicators (requires plugin)
    //     .addTo(controller);

    // }
    
   

 // end of build scene section2


 
 //start of slider animation

//     var sliderSectionPath = new TimelineMax()
//         .add(TweenMax.to($path21, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),1)

//         .add(TweenMax.to($path22, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),2)
//         .add(TweenMax.to('.feaure-image-slider .img-wrap ul', 2, {y:'-25%'}),2)
//         .add(TweenMax.to('.feaure-image-slider .slider-list-1', 2, {opacity:0}),2)
//         .add(TweenMax.to('.feaure-image-slider .slider-list-2', 2, {opacity:1}),2)

//         .add(TweenMax.to($path23, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),3)

        
//         .add(TweenMax.to($path24, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),4)
//         .add(TweenMax.to('.feaure-image-slider .img-wrap ul', 2, {y:'-50%'}),4)
//         .add(TweenMax.to('.feaure-image-slider .slider-list-2', 2, {opacity:0}),4)
//         .add(TweenMax.to('.feaure-image-slider .slider-list-3', 2, {opacity:1}),4)
        

//         .add(TweenMax.to($path25, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),5)


//         .add(TweenMax.to($path26, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),6)
//         .add(TweenMax.to('.feaure-image-slider .img-wrap ul', 2, {y:'-75%'}),6)
//         .add(TweenMax.to('.feaure-image-slider .slider-list-3', 2, {opacity:0}),6)
//         .add(TweenMax.to('.feaure-image-slider .slider-list-4', 2, {opacity:1}),6)
     
        
//         .add(TweenMax.to($path27, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),7)
//         .add(TweenMax.to($path28, 1, {strokeDashoffset: 0, ease:Linear.easeNone}),8)


// if ( screen.width < 740 ){     
//     var slideranimationpath = new ScrollMagic.Scene({
//         triggerElement: "#jio-fiber-feature-wrap", 
//         duration:1300,
//         triggerHook: 0.1
//     })
//     .setTween(sliderSectionPath)
//     .setPin("#jio-fiber-feature-wrap")
//     // .addIndicators() // add indicators (requires plugin)
//     .addTo(controller);
	
// 	}

    
// else{
//      var slideranimationpath = new ScrollMagic.Scene({
//         triggerElement: "#jio-fiber-feature-wrap", 
//         duration:1600,
//         triggerHook: 0.1
//         })
//         .setTween(sliderSectionPath)
//         .setPin("#jio-fiber-feature-wrap")
//         // .addIndicators() // add indicators (requires plugin)
//         .addTo(controller);
//     }
       

    



//start of fiber form animation

//     var formanimation = new TimelineMax()
//         .add(TweenMax.to($path30, 2, {strokeDashoffset: 0, ease:Linear.easeNone}))
//         .add(TweenMax.to('.fiber-form-head.fill-head-text', 2, {opacity:1}))
//         .add(TweenMax.to($path31, 2, {strokeDashoffset: 0, ease:Linear.easeNone}))
//         .add(TweenMax.to($path32, 2, {strokeDashoffset: 0, ease:Linear.easeNone}))
//         .add(TweenMax.to($path33, 2, {strokeDashoffset: 0, ease:Linear.easeNone}))

//         .add(TweenMax.to($path34, 2, {strokeDashoffset: 0, ease:Linear.easeNone}))
//         .add(TweenMax.to($path35, 2, {strokeDashoffset: 0, ease:Linear.easeNone}))

//         .add(TweenMax.to('.submit-path', 2, {opacity:1}))

//     var formanimationpath = new ScrollMagic.Scene({
//         triggerElement: "#jio-fiber-form", 
//         duration: 2300,
//         triggerHook: 0.03
//     })
    
//     .setTween(formanimation)
//     .setPin("#jio-fiber-form")
//     //.addIndicators() // add indicators (requires plugin)
//     .addTo(controller);



//  //end of slider animation


    
 

// $(setup)  
//     function setup() {   
//       $('#fttx-select1 select').zelect({ placeholder:'Select City' })   
//       $('#fttx-select2 select').zelect({ placeholder:'City' })
//       $('#fttx-select3 select').zelect({ placeholder:'Pincode' })   
//       $('#fttx-select4 select').zelect({ placeholder:'Building' })  
//       $('#fttx-select5 select').zelect({ placeholder:'My Position' })  
          
//     };     
    
//       $("#designation").hide();  
//     // option chairman change
//     $("select").change(function(){
//         $(this).find("option:selected").each(function(){            
//             if($(this).attr("value")=="others"){
//                 $(".box-fttx").not(".others-person-option").show();
//                 $("#designation").show();
//                 $(".chairman-person").hide();
                 
//                 $('html,body').animate({scrollTop: $($('.position-option')).offset().top - 60}, 1000);   
                
//             }
//             else if($(this).attr("value")=="chairman"){
//                 $(".box-fttx").not(".chairman-person").hide();
//                 $(".chairman-person").show();
//                 $("#designation").hide();
                
//             }
            
            
//         });
//     }).change();
    


// $('#fullpage').fullpage();

 
});  
