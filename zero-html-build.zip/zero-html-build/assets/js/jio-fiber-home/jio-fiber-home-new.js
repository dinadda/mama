$(document).ready(function(){

//$("html").niceScroll({
   // scrollspeed:"170",
    //autohidemode:false,
    //zindex:"10000",
    //horizrailenabled:false
//});

$('[data-toggle="tooltip"]').tooltip();

// scrollmagic js start

// init controller
var controller = new ScrollMagic.Controller({});  
    // build scene
    var wallscene = new ScrollMagic.Scene({
        triggerElement: "#inner-fiber-section", 
        duration: 2000,
        tweenChanges: true,
        triggerHook: 0.3
    })
    .setClassToggle("#inner-fiber-section" ,"active")
    // .addIndicators() // add indicators (requires plugin)
    .addTo(controller);	

     // build scene
	
	 // define movement of panels prem
		var wipeAnimation = new TimelineMax()
			// animate to second panel
			.to("#slideContainer", 1, {z: 0})		// move back in 3D space
			.to("#slideContainer", 1,   {x: "-50%"})	// move in to first panel
			.to("#slideContainer", 0.5, {z: 0})
		
			.add(TweenMax.to('.sence-anim .slider-text-1', 2, {opacity:0}),0)
			.add(TweenMax.to('.sence-anim .slider-text-2', 2, {opacity:1}),1)
			 
			
			//.add(TweenMax.to('#masthead-fiber-section2 .slider-text', 1, {opacity:0}),2)
			 //.add(TweenMax.to('#masthead-fiber-section2 .slider-text-2', 2, {opacity:1}),2)					// move back to origin in 3D space
			// animate to third panel
			//.to("#slideContainer", 0.5, {z: -150, delay: 1})
			//.to("#slideContainer", 1,   {x: "-50%"})
			//.to("#slideContainer", 0.5, {z: 0})
			// animate to forth panel
			//.to("#slideContainer", 0.5, {z: -150, delay: 1})
			//.to("#slideContainer", 1,   {x: "-75%"})
			//.to("#slideContainer", 0.5, {z: 0});
			 			
								
    var wallsetpin = new ScrollMagic.Scene({
        triggerElement: "#masthead-fiber-section2", 
        duration: 800,
        triggerHook: "onLeave"
    })
    .setPin("#masthead-fiber-section2")
	.setClassToggle('.prem_one', 'active')
	.setTween(wipeAnimation)
    //.addIndicators() // add indicators (requires plugin)
    .addTo(controller);



 
});  
