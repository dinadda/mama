
$(document).ready(function(){
    $('.toggle').click(function(){
      $('.toggle').toggleClass('visible');
	  $('.resp_menu').toggleClass('visible');	  
    });
	
	//responsive menu toggle
	$('.list_menu li').click(function(e) {
		$(this).siblings().find("ul").slideUp();
		$(this).children('ul').slideToggle();
		$(this).siblings().find("ul li").removeClass("active");
		$(this).siblings().removeClass("active");
		$(this).toggleClass("active");
		e.stopPropagation();
	});
	
});

