
$(document).ready(function() {
	$('.slider-com').slick({
  dots: false,
  infinite: true,
  speed: 1000,
  slidesToShow: 1,
  slidesToScroll: 1,
  autoplay:true,
  
});

	$('.shop-now').slick({
  dots: false,
  infinite: false,
  speed: 300,
  slidesToShow: 5,
  slidesToScroll: 1,
  responsive: [
  	{
      breakpoint: 1200,
      settings: {
        slidesToShow: 4,
        slidesToScroll: 1,
        infinite: false,
        dots: false
      }
    },
    {
      breakpoint: 1024,
      settings: {
        slidesToShow: 3,
        slidesToScroll: 1,
        infinite: false,
        dots: false
      }
    },
	{
      breakpoint: 800,
      settings: {
        slidesToShow: 2,
        slidesToScroll: 1,
        infinite: false,
        dots: false
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        slidesToScroll: 1
      }
    }
    // You can unslick at a given breakpoint now by adding:
    // settings: "unslick"
    // instead of a settings object
  ]
});
	
	
	$('.show-menu').click(function() {
		//alert("hi");
		$("#menu").slideToggle('fast');
		
});
	
$(window).on('resize', function() {
   
        if ($(window).width() < 760) {
			//alert($(window).width());
			$("#menu").hide();
            $('#menu li').click(function (e) {
					// alert("1");
					$(this).siblings().find("ul").slideUp();
					 $(this).children('ul').slideDown();
				 // $(this).children('ul').slideToggle();
				  e.stopPropagation();
				});
        } else {
            $(".hidden").hide();
			$("#menu").show();
        }
  
});

	if ($(window).width() < 760) {
		
		$('#menu li').click(function (e) {
					// alert("1");
					$(this).siblings().find("ul").slideUp();
					 $(this).children('ul').slideToggle();
				 // $(this).children('ul').slideToggle();
				  e.stopPropagation();
				});
  }
 
});
window.onorientationchange = function() {  	window.location.reload(); };



function userLogin()
	{
					$("#signin-pop-up").popUpWindow({action: "close"});
					$("#logout").show();
					$("#register").hide();
					$( "#signin").hide();
					$( "#user").text( "Hi, SHE" );
					
	}
	$("#user").click(function() {
			//alert("hi");
			$( "#userMenu").toggle();
		});
		$(document).mouseup(function (e)
		{
			var container = $("#signinCont");
		
			if (!container.is(e.target) // if the target of the click isn't the container...
				&& container.has(e.target).length === 0) // ... nor a descendant of the container
			{
				$( "#userMenu").hide();
			}
			
			
		
		});	 
	function openModal(m)
{
	//alert("hi");
	$('html, body').animate({scrollTop: '0px'}, 0);
	$(m).popUpWindow({action: "open"});
	//$("#register-pop-up").popUpWindow({action: "open"});
}
function openCloseModal(c,o)
{
	$(c).popUpWindow({action: "close"});
	$(o).popUpWindow({action: "open"});
}
	function openSmallModal(m)
{
	//alert("hi");
	$('html, body').animate({scrollTop: '0px'}, 0);
	$(m).popUpWindow({action: "open",
            size: "small"});
	//$("#register-pop-up").popUpWindow({action: "open"});
}
 $(function () {
		$('#dp1').fdatepicker({
					format: 'mm-dd-yyyy'
				});
 });
 $.widget( "custom.catcomplete", $.ui.autocomplete, {
		_create: function() {
			this._super();
			this.widget().menu( "option", "items", "> :not(.ui-autocomplete-category)" );
		},
		_renderMenu: function( ul, items ) {
			var that = this,
				currentCategory = "";
			$.each( items, function( index, item ) {
				var li;
				if ( item.category != currentCategory ) {
					ul.append( "<li class='ui-autocomplete-category'>" + item.category + "</li>" );
					currentCategory = item.category;
				}
				li = that._renderItemData( ul, item );
				if ( item.category ) {
					li.attr( "aria-label", item.category + " : " + item.label );
				}
			});
		}
	});
	$(function() {
		var data = [
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "shirt" },
			{ label: "shirt", category: "Men" }
		];

		$( "#search" ).catcomplete({
			delay: 0,
			source: data
		});
		$( "#search1" ).catcomplete({
			delay: 0,
			source: data
		});
	});
	
	
		$('.toggle-menu').jPushMenu();
	 $('.prodlist.prodlist-click li').click(function (e) {
					// alert("1");
					$(this).siblings().find("ul").slideUp();
					$(this).children('ul').slideToggle();
					$(this).siblings().find("ul li").removeClass("active");
					 $(this).siblings().removeClass("active");
					//$(this).children('li').removeClass("active");
					  $(this).toggleClass("active");
				 // $(this).children('ul').slideToggle();
				  e.stopPropagation();
				});